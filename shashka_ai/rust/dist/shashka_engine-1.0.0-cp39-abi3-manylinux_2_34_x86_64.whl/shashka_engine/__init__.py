from .shashka_engine import *

__doc__ = shashka_engine.__doc__
if hasattr(shashka_engine, "__all__"):
    __all__ = shashka_engine.__all__